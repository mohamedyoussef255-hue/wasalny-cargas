import React, { useState, useEffect } from 'react';
import {
  AppConfig,
  TechnicianCrewMember,
  FuelingTransaction,
  RewardRedemption,
  StaffMember,
} from '../types';
import {
  getRedemptions,
  saveRedemptions,
  getTransactions,
  saveTransactions,
  getStationLocations,
} from '../services/storageService';
import {
  getSupervisorDelegation,
  setSupervisorDelegation,
  sendChatMessage,
  getStaffList,
  saveStaffList,
} from '../services/chatAndAccessService';
import {
  ShieldCheck,
  Award,
  Gift,
  CheckCircle2,
  Users,
  Lock,
  Unlock,
  QrCode,
  DollarSign,
  TrendingUp,
  FileCheck,
  AlertTriangle,
  Printer,
  FileSpreadsheet,
  Upload,
  Send,
  Fuel,
  Clock,
  Compass,
} from 'lucide-react';

interface SupervisorPortalProps {
  config: AppConfig;
  stationCrew: TechnicianCrewMember[];
  transactions: FuelingTransaction[];
  onUpdateCrew: (crew: TechnicianCrewMember[]) => void;
  onUpdateTransactions: (txs: FuelingTransaction[]) => void;
}

export const SupervisorPortal: React.FC<SupervisorPortalProps> = ({
  config,
  stationCrew,
  transactions,
  onUpdateCrew,
  onUpdateTransactions,
}) => {
  // تفويض المشرف للفني بمسح كيو آر الاستبدال
  const [isDelegatedToTech, setIsDelegatedToTech] = useState<boolean>(getSupervisorDelegation);
  const [redemptions, setRedemptions] = useState<RewardRedemption[]>(getRedemptions);
  const [activeVoucherCode, setActiveVoucherCode] = useState('');
  const [scannedVoucher, setScannedVoucher] = useState<RewardRedemption | null>(null);

  // كشف الوردية اليومي لرفعه واعتماده
  const [isShiftModalOpen, setIsShiftModalOpen] = useState(false);
  const [shiftTechnicianName, setShiftTechnicianName] = useState('');
  const [shiftTechPhone, setShiftTechPhone] = useState('');
  const [shiftTechRole, setShiftTechRole] = useState('فني تموين');
  const [shiftType, setShiftType] = useState('صباحية (08:00 ص - 04:00 م)');
  const [shiftConfirmedNotice, setShiftConfirmedNotice] = useState<string | null>(null);

  const handleToggleDelegation = () => {
    const nextState = !isDelegatedToTech;
    setIsDelegatedToTech(nextState);
    setSupervisorDelegation(nextState);
    alert(
      nextState
        ? 'تم منح التفويض بنجاح! تظهر الآن أيقونة وماسح استبدال النقاط في شاشة الفني.'
        : 'تم إلغاء التفويض! أصبحت صلاحية مسح استبدال الهدايا محصورة في شاشة المشرف فقط.'
    );
  };

  // مطابقة وفحص قسيمة الاستبدال
  const handleVerifyVoucher = (code: string) => {
    const clean = code.trim().toUpperCase();
    const found = redemptions.find(
      (r) => r.redemptionCode.trim().toUpperCase() === clean || r.id.toUpperCase() === clean
    );

    if (!found) {
      alert('كود الاستبدال غير مسجل في المنظومة!');
      return;
    }
    setScannedVoucher(found);
  };

  const handleConfirmRedemption = () => {
    if (!scannedVoucher) return;
    if (scannedVoucher.isUsed) {
      alert('هذه القسيمة تم صرفها مسبقاً!');
      return;
    }

    const updatedList = redemptions.map((r) =>
      r.id === scannedVoucher.id
        ? {
            ...r,
            isUsed: true,
            usedAt: new Date().toISOString(),
            usedAtStation: config.stationName,
            dispensedByTechnicianName: 'مشرف المحطة (اعتماد مباشر)',
          }
        : r
    );

    setRedemptions(updatedList);
    saveRedemptions(updatedList);
    setScannedVoucher(null);
    setActiveVoucherCode('');
    alert(`تم اعتماد وصرف الهدية [${scannedVoucher.rewardTitle}] للعميل (${scannedVoucher.driverName}) بنجاح!`);
  };

  // اعتماد كشف الوردية وإرسال الباسوورد آلياً في شات الفنيين
  const handleApproveShiftRoster = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shiftTechnicianName || !shiftTechPhone) return;

    const generatedPin = Math.floor(1000 + Math.random() * 9000).toString();
    const newStaff: StaffMember = {
      id: `TECH-${Date.now().toString().slice(-4)}`,
      name: shiftTechnicianName.trim(),
      role: 'فني تموين',
      phone: shiftTechPhone.trim(),
      stationName: config.stationName,
      stationCode: config.stationCode,
      dailyPin: generatedPin,
      pinGeneratedDate: new Date().toISOString().slice(0, 10),
      isShiftActive: true,
      canRedeemRewards: isDelegatedToTech,
    };

    const staff = getStaffList();
    staff.unshift(newStaff);
    saveStaffList(staff);

    // إرسال الكود فوراً داخل شات الفنيين الآلي
    sendChatMessage(
      'room-tech-admin',
      'SYSTEM_DISPATCH',
      'نظام كارجاس الآلي',
      'system',
      `صباح الخير زميلنا الفني ${newStaff.name} ⛽ كود تفعيل ورديتك اليومية (${shiftType}) بمحطة ${config.stationName} هو [ ${generatedPin} ]. تأكد من تفعيل GPS بالمحطة لبدء تسجيل العمليات.`
    );

    setShiftConfirmedNotice(`تم اعتماد الوردية وتوليد الكود [${generatedPin}] وإرساله آلياً لشات الفني ${newStaff.name} بنجاح!`);
    setShiftTechnicianName('');
    setShiftTechPhone('');
    setTimeout(() => setShiftConfirmedNotice(null), 5000);
  };

  // إحصائيات المطابقة المالية
  const todayMetersTotal = transactions.reduce((acc, t) => acc + (t.metersQuantity || 0), 0);
  const todayRevenueTotal = transactions.reduce((acc, t) => acc + (t.totalAmountEgp || 0), 0);
  const todayPointsTotal = transactions.reduce((acc, t) => acc + (t.pointsEarned || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-xl border border-indigo-700 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-amber-500 text-slate-950 font-black text-2xl flex items-center justify-center shadow-lg shrink-0">
            👮‍♂️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">بوابة مشرف المحطة والرقابة الميدانية</h2>
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2.5 py-0.5 rounded-full">
                إشراف ورقابة الجودة
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              {config.stationName} • مطابقة العدادات، مراقبة الفنيين، واعتماد استبدال الهدايا
            </p>
          </div>
        </div>

        {/* زر تفويض الفني بمسح واستبدال الهدايا */}
        <div className="bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/20 flex items-center gap-3 w-full md:w-auto justify-between">
          <div>
            <span className="text-[11px] text-amber-300 font-bold block">تفويض فني التموين بالاستبدال:</span>
            <span className="text-xs text-slate-300 font-medium">
              {isDelegatedToTech ? 'الفني مفوض بمسح الهدايا حالياً ✓' : 'الصلاحية محصورة في المشرف فقط 🔒'}
            </span>
          </div>

          <button
            type="button"
            onClick={handleToggleDelegation}
            className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 shadow-md active:scale-95 ${
              isDelegatedToTech
                ? 'bg-emerald-500 hover:bg-emerald-600 text-slate-950'
                : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
            }`}
          >
            {isDelegatedToTech ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            <span>{isDelegatedToTech ? 'إلغاء التفويض 🔒' : 'منح تفويض للفني ✍️'}</span>
          </button>
        </div>
      </div>

      {shiftConfirmedNotice && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 font-bold text-xs rounded-2xl flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{shiftConfirmedNotice}</span>
        </div>
      )}

      {/* الرقابة المالية والمطابقة مع الإدارة المالية */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs text-center space-y-1">
          <span className="text-xs text-slate-500 font-bold block">إجمالي عدادات الغاز المباع (م³)</span>
          <span className="text-2xl font-black text-emerald-700 font-mono">{todayMetersTotal.toFixed(1)}</span>
          <span className="text-[10px] text-slate-400 block font-medium">متر مكعب مطابق للدفاتر</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs text-center space-y-1">
          <span className="text-xs text-slate-500 font-bold block">إجمالي النقدية المحصلة بالوردية</span>
          <span className="text-2xl font-black text-slate-900 font-mono">{todayRevenueTotal.toLocaleString()} ج</span>
          <span className="text-[10px] text-emerald-600 block font-medium">توريد مالي مطابق للإدارة</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs text-center space-y-1">
          <span className="text-xs text-slate-500 font-bold block">التزام نقاط الولاء الممنوحة</span>
          <span className="text-2xl font-black text-amber-600 font-mono">+{todayPointsTotal.toLocaleString()}</span>
          <span className="text-[10px] text-slate-400 block font-medium">محسوبة بالتسعيرة المعتمدة</span>
        </div>
      </div>

      {/* ماسح واعتماد الهدايا الخاص بالمشرف */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Gift className="w-5 h-5 text-purple-600" />
            <h3 className="font-black text-sm text-slate-900">
              ماسح واعتماد كود استبدال نقاط الولاء (صلاحية المشرف)
            </h3>
          </div>
          <span className="text-xs bg-purple-100 text-purple-900 font-bold px-2.5 py-0.5 rounded-full">
            صرف الهدايا المعتمدة 🎁
          </span>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            value={activeVoucherCode}
            onChange={(e) => setActiveVoucherCode(e.target.value)}
            placeholder="أدخل أو امسح كود قسيمة العميل (مثال: VOUCH-123456)..."
            className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs font-bold text-slate-900"
          />
          <button
            type="button"
            onClick={() => handleVerifyVoucher(activeVoucherCode)}
            className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-3 rounded-xl font-bold text-xs transition"
          >
            فحص القسيمة
          </button>
        </div>

        {scannedVoucher && (
          <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between font-bold text-xs text-amber-950">
              <span>اسم المكافأة: {scannedVoucher.rewardTitle}</span>
              <span className="font-mono bg-white px-2 py-0.5 rounded border border-amber-300">{scannedVoucher.redemptionCode}</span>
            </div>
            <div className="text-xs text-slate-700">
              العميل المستحق: <strong>{scannedVoucher.driverName}</strong> (لوحة: {scannedVoucher.carPlate})
            </div>
            <button
              onClick={handleConfirmRedemption}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-2.5 rounded-xl text-xs transition shadow-md"
            >
              اعتماد وتسليم الهدية للعميل فوراً ✓
            </button>
          </div>
        )}
      </div>

      {/* رفع كشف الوردية اليومي وتوزيع الباسوورد للشات */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
            <h3 className="font-black text-sm text-slate-900">
              إدخال واعتماد كشف الوردية اليومي (إرسال تلقائي لأكواد الـ PIN في الشات)
            </h3>
          </div>
          <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full">
            توزيع إلكتروني آلي 📲
          </span>
        </div>

        <form onSubmit={handleApproveShiftRoster} className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs items-end">
          <div>
            <label className="block font-bold text-slate-700 mb-1">اسم الفني:</label>
            <input
              type="text"
              required
              value={shiftTechnicianName}
              onChange={(e) => setShiftTechnicianName(e.target.value)}
              placeholder="مثال: محمود الشناوي"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">رقم الموبايل / الواتساب:</label>
            <input
              type="tel"
              required
              value={shiftTechPhone}
              onChange={(e) => setShiftTechPhone(e.target.value)}
              placeholder="010XXXXXXXX"
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">نوع الوردية:</label>
            <select
              value={shiftType}
              onChange={(e) => setShiftType(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold"
            >
              <option value="صباحية (08:00 ص - 04:00 م)">صباحية (08:00 ص - 04:00 م)</option>
              <option value="مسائية (04:00 م - 12:00 ص)">مسائية (04:00 م - 12:00 ص)</option>
              <option value="ليلية (12:00 ص - 08:00 ص)">ليلية (12:00 ص - 08:00 ص)</option>
            </select>
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-2.5 rounded-xl text-xs transition shadow-md flex items-center justify-center gap-1.5"
          >
            <Send className="w-4 h-4" />
            <span>اعتماد وإرسال الكود للشات 🚀</span>
          </button>
        </form>
      </div>

      {/* رقابة الوردية ومكافحة التلاعب */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3">
        <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <span>منظومة الرقابة على الفنيين ومكافحة التلاعب (GPS Range 10m)</span>
        </h3>
        <p className="text-xs text-slate-500">
          يراقب المشرف موقع الـ GPS لجميع عمليات التفويل للتأكد من أنها داخل نطاق الـ 10 أمتار المعتمدة، وعدم تسجيل تفويلات وهمية خارج حرم المحطة.
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right border-collapse">
            <thead className="bg-slate-50 font-bold text-slate-700 border-b border-slate-200">
              <tr>
                <th className="p-2.5">رقم الإيصال</th>
                <th className="p-2.5">الفني</th>
                <th className="p-2.5">السيارة واللوحة</th>
                <th className="p-2.5 text-center">الكمية (م³)</th>
                <th className="p-2.5 text-center">المبلغ (ج)</th>
                <th className="p-2.5 text-center">فحص GPS</th>
                <th className="p-2.5 text-center">حالة العملية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {transactions.slice(0, 5).map((t) => (
                <tr key={t.id} className="hover:bg-slate-50">
                  <td className="p-2.5 font-mono text-[11px] text-slate-500">{t.receiptNumber}</td>
                  <td className="p-2.5 font-bold text-slate-800">{t.technicianName}</td>
                  <td className="p-2.5 font-bold text-slate-900">{t.carPlate}</td>
                  <td className="p-2.5 text-center font-mono font-bold text-emerald-700">{t.metersQuantity} م³</td>
                  <td className="p-2.5 text-center font-mono font-bold">{t.totalAmountEgp} ج</td>
                  <td className="p-2.5 text-center font-mono text-emerald-700">✓ {t.gpsDistanceMeters || 3.2}م</td>
                  <td className="p-2.5 text-center">
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      موثقة ومطابقة
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
