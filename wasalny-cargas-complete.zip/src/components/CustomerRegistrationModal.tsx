import React, { useState } from 'react';
import { DriverProfile, AppConfig, VehicleLicenseAndConversion } from '../types';
import { CARGAS_LOGO_SVG } from '../navigation/utils/cargasLogo';
import { Car, User, Phone, Mail, ShieldCheck, CheckCircle2, ChevronRight, Fuel, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  config: AppConfig;
  onSaveDriver: (profile: DriverProfile) => void;
  onClose?: () => void;
}

export const CustomerRegistrationModal: React.FC<Props> = ({ isOpen, config, onSaveDriver, onClose }) => {
  const [step, setStep] = useState<'splash' | 'personal' | 'vehicle'>('splash');
  
  // بيانات العميل الشخصية
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [isWhatsApp, setIsWhatsApp] = useState(true);
  const [whatsappPhone, setWhatsappPhone] = useState('');
  const [email, setEmail] = useState('');

  // بيانات رخصة السيارة والتحويل
  const [carPlate, setCarPlate] = useState('');
  const [carModel, setCarModel] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [trafficDepartment, setTrafficDepartment] = useState('');
  const [conversionCompany, setConversionCompany] = useState('كارجاس');
  const [cylinderCapacity, setCylinderCapacity] = useState(70);
  const [cylinderSerial, setCylinderSerial] = useState('');
  const [lastInspection, setLastInspection] = useState(new Date().toISOString().slice(0, 10));

  if (!isOpen) return null;

  // شاشة الترحيب باللوجو (Splash Screen)
  if (step === 'splash') {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
        <div className="w-28 h-28 rounded-full bg-white p-2 shadow-2xl border-4 border-emerald-500 mb-6 animate-bounce">
          {config.customAppLogoUrl ? (
            <img src={config.customAppLogoUrl} alt="Logo" className="w-full h-full object-contain" />
          ) : (
            <div dangerouslySetInnerHTML={{ __html: CARGAS_LOGO_SVG }} className="w-full h-full" />
          )}
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white mb-2">
          {config.appName || 'منظومة كارجاس وبرنامج الولاء الذكي'}
        </h1>
        <p className="text-emerald-400 font-bold text-sm mb-8">
          أهلاً بك في بوابة {config.customTexts?.welcomeDriverLabel || 'صديق كارجاس'}
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => setStep('personal')}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-black px-8 py-3.5 rounded-2xl text-base shadow-xl transition transform active:scale-95 flex items-center justify-center gap-2"
          >
            <span>تسجيل وتأكيد بيانات العضوية والسيارة</span>
            <ChevronRight className="w-5 h-5 rotate-180" />
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-6 py-3.5 rounded-2xl text-sm transition"
            >
              الدخول كزائر
            </button>
          )}
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const licenseDetails: VehicleLicenseAndConversion = {
      licenseNumber,
      trafficDepartment,
      chassisNumber: '',
      motorNumber: '',
      conversionCompany,
      cylinderCapacityLiters: Number(cylinderCapacity),
      cylinderSerialNumber: cylinderSerial,
      lastInspectionDate: lastInspection,
      nextInspectionDueDate: new Date(Date.now() + 3 * 365 * 86400000).toISOString().slice(0, 10),
    };

    const newProfile: DriverProfile = {
      id: `DRV-${Date.now().toString().slice(-5)}`,
      name: name.trim() || 'صديق كارجاس',
      phone: phone.trim() || '01000000000',
      isWhatsApp,
      whatsappPhone: isWhatsApp ? phone.trim() : whatsappPhone.trim(),
      email: email.trim(),
      carPlate: carPlate.trim() || 'أ ب ج 1 2 3 4',
      carModel: carModel.trim() || 'سيارة ملاكي غاز',
      cngCylinderCapacity: Number(cylinderCapacity),
      odometerKm: 85000,
      points: 150, // بونص ترحيبي
      totalMetersFueled: 0,
      totalSpentEgp: 0,
      registeredAt: new Date().toISOString(),
      licenseDetails,
      maintenanceSchedule: [],
    };

    onSaveDriver(newProfile);
    if (onClose) onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 text-right my-8 relative">
        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 left-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="border-b border-slate-100 pb-4 text-center">
          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            استمارة تسجيل {config.customTexts?.welcomeDriverLabel || 'صديق كارجاس'}
          </span>
          <h2 className="text-xl font-black text-slate-900 mt-2">
            {step === 'personal' ? '1. البيانات الشخصية وبيانات التواصل' : '2. بيانات رخصة السيارة والتحويل للغاز'}
          </h2>
        </div>

        <form onSubmit={step === 'personal' ? (e) => { e.preventDefault(); setStep('vehicle'); } : handleSubmit} className="space-y-4 text-xs">
          {step === 'personal' ? (
            <>
              <div>
                <label className="block font-bold text-slate-700 mb-1">الاسم بالكامل *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: أحمد عبد الرحمن مصطفى"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">رقم الموبايل *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="010XXXXXXXX"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isWhatsApp}
                    onChange={(e) => setIsWhatsApp(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded"
                  />
                  <span className="font-bold text-slate-800">رقم الموبايل أعلاه هو نفسه رقم الواتساب الرسمي</span>
                </label>
                {!isWhatsApp && (
                  <div>
                    <label className="block text-[11px] text-slate-500 mb-1">اكتب رقم الواتساب الخاص بك:</label>
                    <input
                      type="tel"
                      value={whatsappPhone}
                      onChange={(e) => setWhatsappPhone(e.target.value)}
                      placeholder="رقم الواتساب لاستقبال الهدايا..."
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl font-mono text-xs"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">البريد الإلكتروني (اختياري)</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3 rounded-xl text-sm transition mt-4 shadow-md"
              >
                التالي: بيانات رخصة السيارة والتحويل ←
              </button>
            </>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">رقم لوحة السيارة *</label>
                  <input
                    type="text"
                    required
                    value={carPlate}
                    onChange={(e) => setCarPlate(e.target.value)}
                    placeholder="س ر ق 4 5 1 2"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">نوع وموديل السيارة *</label>
                  <input
                    type="text"
                    required
                    value={carModel}
                    onChange={(e) => setCarModel(e.target.value)}
                    placeholder="نيسان صني 2023"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">رقم رخصة التسيير</label>
                  <input
                    type="text"
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    placeholder="رقم الرخصة من المرور..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">وحدة المرور التابع لها</label>
                  <input
                    type="text"
                    value={trafficDepartment}
                    onChange={(e) => setTrafficDepartment(e.target.value)}
                    placeholder="مرور مدينة نصر / شبرا..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-3">
                <h4 className="font-black text-emerald-900 flex items-center gap-1.5">
                  <Fuel className="w-4 h-4 text-emerald-700" />
                  <span>بيانات منظومة التحويل والأسطوانة:</span>
                </h4>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">تبعية التحويل لشركة:</label>
                    <select
                      value={conversionCompany}
                      onChange={(e) => setConversionCompany(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                    >
                      <option value="كارجاس (CARGAS)">شركة كارجاس (CARGAS)</option>
                      <option value="غازتك (Gastec)">شركة غازتك (Gastec)</option>
                      <option value="ماستر جاس">ماستر جاس (Master Gas)</option>
                      <option value="عربية غاز">عربية غاز</option>
                      <option value="أخرى / تصنيع وكلاء">أخرى / مصنعية وكلاء</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">حجم وسعة الأسطوانة (لتر):</label>
                    <select
                      value={cylinderCapacity}
                      onChange={(e) => setCylinderCapacity(Number(e.target.value))}
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl font-bold font-mono text-slate-900"
                    >
                      <option value="60">60 لتر (~ 13.5 م³ غاز)</option>
                      <option value="70">70 لتر (~ 16.0 م³ غاز) [شائع]</option>
                      <option value="80">80 لتر (~ 18.5 م³ غاز)</option>
                      <option value="90">90 لتر (~ 21.0 م³ غاز)</option>
                      <option value="100">100 لتر (~ 24.0 م³ غاز)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">رقم أسطوانة الغاز:</label>
                    <input
                      type="text"
                      value={cylinderSerial}
                      onChange={(e) => setCylinderSerial(e.target.value)}
                      placeholder="الرقم المحفور على الأسطوانة"
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl font-mono text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">تاريخ آخر فحص واختبار دوري:</label>
                    <input
                      type="date"
                      value={lastInspection}
                      onChange={(e) => setLastInspection(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStep('personal')}
                  className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                >
                  السابق
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-black py-3 rounded-xl shadow-lg transition"
                >
                  إتمام التسجيل وتأكيد العضوية 🚗✓
                </button>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
};
