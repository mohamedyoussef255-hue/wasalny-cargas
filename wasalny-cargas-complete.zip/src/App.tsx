import React, { useState, useEffect } from 'react';
import {
  AppConfig,
  DriverProfile,
  FuelingTransaction,
  RewardItem,
  TechnicianCrewMember,
  CargasStationLocation,
  UserRole,
} from './types';
import {
  getAppConfig,
  getDriverProfile,
  getStationCrew,
  getTransactions,
  getRewards,
  getStationLocations,
  saveAppConfig,
  saveDriverProfile,
  saveStationCrew,
  saveTransactions,
  saveRewards,
  saveStationLocations,
  restoreClassicV1Snapshot,
} from './services/storageService';
import { Header } from './components/Header';
import { AdminModal } from './components/AdminModal';
import { DriverPortal } from './components/DriverPortal';
import { TechnicianPortal } from './components/TechnicianPortal';
import { AdminPortal } from './components/AdminPortal';
import { FinancialManagementPortal } from './components/FinancialManagementPortal';
import { FinanceModal } from './components/FinanceModal';
import { MoenAssistant } from './components/MoenAssistant';
import { SettingsProvider, useSettings } from './context/SettingsContext';
import { SupervisorPortal } from './components/SupervisorPortal';
import { CustomerRegistrationModal } from './components/CustomerRegistrationModal';
import { InternalChatModal } from './components/InternalChatModal';
import { ShieldCheck, Sparkles, Fuel, Car, Wrench, Heart, RotateCcw, MapPin, DollarSign, MessageCircle, Users } from 'lucide-react';

export default function App() {
  return (
    <SettingsProvider>
      <MainAppContent />
    </SettingsProvider>
  );
}

function MainAppContent() {
  const { gasPrice, stationName, updateSetting } = useSettings();

  const [config, setConfig] = useState<AppConfig>(() => {
    const initial = getAppConfig();
    return {
      ...initial,
      gasPricePerMeter: gasPrice || initial.gasPricePerMeter,
      stationName: stationName || initial.stationName,
    };
  });
  const [driver, setDriver] = useState<DriverProfile>(getDriverProfile);
  const [crew, setCrew] = useState<TechnicianCrewMember[]>(getStationCrew);
  const [rewards, setRewards] = useState<RewardItem[]>(getRewards);
  const [transactions, setTransactions] = useState<FuelingTransaction[]>(getTransactions);
  const [stations, setStations] = useState<CargasStationLocation[]>(getStationLocations);

  // Customer First-Time Registration Modal
  const [isCustomerRegOpen, setIsCustomerRegOpen] = useState<boolean>(() => {
    return !localStorage.getItem('cargas_driver_profile_registered');
  });

  // Internal In-App Chat Modal
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);

  // Sync settings context gasPrice and stationName to config
  useEffect(() => {
    if (gasPrice && config.gasPricePerMeter !== gasPrice) {
      setConfig((prev) => ({ ...prev, gasPricePerMeter: gasPrice }));
    }
    if (stationName && config.stationName !== stationName) {
      setConfig((prev) => ({ ...prev, stationName }));
    }
  }, [gasPrice, stationName]);

  const [currentRole, setCurrentRole] = useState<UserRole>('driver');
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [isFinanceModalOpen, setIsFinanceModalOpen] = useState(false);
  const [isFinanceUnlocked, setIsFinanceUnlocked] = useState(false);

  // Sync dark mode class
  useEffect(() => {
    if (config.isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [config.isDarkMode]);

  const handleToggleTheme = () => {
    const updated = { ...config, isDarkMode: !config.isDarkMode };
    setConfig(updated);
    saveAppConfig(updated);
  };

  const handleRoleChange = (role: UserRole) => {
    if (role === 'admin' && !isAdminUnlocked) {
      setIsAdminModalOpen(true);
      return;
    }
    if (role === 'finance' && !isFinanceUnlocked && !isAdminUnlocked) {
      setIsFinanceModalOpen(true);
      return;
    }
    setCurrentRole(role);
  };

  const handleAdminSuccess = () => {
    setIsAdminUnlocked(true);
    setCurrentRole('admin');
  };

  const handleFinanceSuccess = () => {
    setIsFinanceUnlocked(true);
    setCurrentRole('finance');
  };

  const refreshAllData = () => {
    setConfig(getAppConfig());
    setDriver(getDriverProfile());
    setCrew(getStationCrew());
    setRewards(getRewards());
    setTransactions(getTransactions());
    setStations(getStationLocations());
  };

  const handleRollback = () => {
    restoreClassicV1Snapshot();
    refreshAllData();
  };

  const handleSaveRegisteredDriver = (newDriver: DriverProfile) => {
    setDriver(newDriver);
    saveDriverProfile(newDriver);
    localStorage.setItem('cargas_driver_profile_registered', 'true');
    setIsCustomerRegOpen(false);
  };

  return (
    <div className={`min-h-screen flex flex-col ${config.isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
      
      {/* Top Header with 5-Click Admin Easter Egg */}
      <Header
        config={config}
        currentRole={currentRole}
        onRoleChange={handleRoleChange}
        onTriggerAdminModal={() => setIsAdminModalOpen(true)}
        isAdminUnlocked={isAdminUnlocked}
        onToggleTheme={handleToggleTheme}
      />

      {/* Role Navigation Quick Bar for Staff & Supervisor */}
      <div className="bg-slate-900 text-white px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-bold hidden sm:inline">تبديل الواجهة:</span>
          
          <button
            onClick={() => handleRoleChange('driver')}
            className={`px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 ${
              currentRole === 'driver' ? 'bg-emerald-600 text-white shadow' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Car className="w-3.5 h-3.5" />
            <span>{config.customTexts?.welcomeDriverLabel || 'صديق كارجاس'}</span>
          </button>

          <button
            onClick={() => handleRoleChange('technician')}
            className={`px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 ${
              currentRole === 'technician' ? 'bg-blue-600 text-white shadow' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Fuel className="w-3.5 h-3.5" />
            <span>فني التموين</span>
          </button>

          <button
            onClick={() => handleRoleChange('supervisor')}
            className={`px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 ${
              currentRole === 'supervisor' ? 'bg-amber-600 text-white shadow' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>مشرف المحطة 👮‍♂️</span>
          </button>

          <button
            onClick={() => handleRoleChange('finance')}
            className={`px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 ${
              currentRole === 'finance' ? 'bg-teal-600 text-white shadow' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>الإدارة المالية 💼</span>
          </button>
        </div>

        {/* In-App Chat Floating Trigger Button */}
        <button
          onClick={() => setIsChatOpen(true)}
          className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black px-3.5 py-1.5 rounded-xl shadow-md flex items-center gap-1.5 transition active:scale-95 shrink-0"
        >
          <MessageCircle className="w-4 h-4" />
          <span>المحادثات والشات الداخلي 💬</span>
        </button>
      </div>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        
        {/* Driver / Customer Portal */}
        {currentRole === 'driver' && (
          <DriverPortal
            config={config}
            driver={driver}
            rewards={rewards}
            transactions={transactions}
            stations={stations}
            crew={crew}
            onUpdateDriver={(d) => {
              setDriver(d);
              saveDriverProfile(d);
            }}
            onRefreshData={refreshAllData}
            onUpdateConfig={(cfg) => {
              setConfig(cfg);
              saveAppConfig(cfg);
            }}
          />
        )}

        {/* Technician Shift & Fueling Scanner Portal */}
        {currentRole === 'technician' && (
          <TechnicianPortal
            config={config}
            stationCrew={crew}
            currentDriver={driver}
            transactions={transactions}
            onUpdateCrew={(c) => {
              setCrew(c);
              saveStationCrew(c);
            }}
            onUpdateDriver={(d) => {
              setDriver(d);
              saveDriverProfile(d);
            }}
            onUpdateTransactions={(txs) => {
              setTransactions(txs);
              saveTransactions(txs);
            }}
            onUpdateConfig={(cfg) => {
              setConfig(cfg);
              saveAppConfig(cfg);
            }}
          />
        )}

        {/* Supervisor Station Control & Audit Portal */}
        {currentRole === 'supervisor' && (
          <SupervisorPortal
            config={config}
            stationCrew={crew}
            transactions={transactions}
            onUpdateCrew={(c) => {
              setCrew(c);
              saveStationCrew(c);
            }}
            onUpdateTransactions={(txs) => {
              setTransactions(txs);
              saveTransactions(txs);
            }}
          />
        )}

        {/* Super Admin Control Center */}
        {currentRole === 'admin' && (
          <AdminPortal
            config={config}
            rewards={rewards}
            stationCrew={crew}
            stations={stations}
            transactions={transactions}
            onUpdateConfig={(cfg) => {
              setConfig(cfg);
              saveAppConfig(cfg);
            }}
            onUpdateRewards={(rews) => {
              setRewards(rews);
              saveRewards(rews);
            }}
            onUpdateCrew={(crw) => {
              setCrew(crw);
              saveStationCrew(crw);
            }}
            onUpdateStations={(sts) => {
              setStations(sts);
              saveStationLocations(sts);
            }}
            onRollbackToClassic={handleRollback}
          />
        )}

        {/* Dedicated Standalone Financial Management Portal (بوابة الإدارة المالية المعتمدة) */}
        {currentRole === 'finance' && (
          <FinancialManagementPortal
            config={config}
            stations={stations}
            transactions={transactions}
            onUpdateStations={(sts) => {
              setStations(sts);
              saveStationLocations(sts);
            }}
            onUpdateConfig={(cfg) => {
              setConfig(cfg);
              saveAppConfig(cfg);
            }}
            isStandalone={true}
            onLogoutFinance={() => {
              setCurrentRole('driver');
              setIsFinanceUnlocked(false);
            }}
          />
        )}
      </main>

      {/* Customer First-Time Registration Modal (Splash + Form) */}
      <CustomerRegistrationModal
        isOpen={isCustomerRegOpen}
        config={config}
        onSaveDriver={handleSaveRegisteredDriver}
        onClose={() => setIsCustomerRegOpen(false)}
      />

      {/* Internal In-App Chat Modal */}
      <InternalChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        currentRole={currentRole}
        config={config}
        currentUserName={
          currentRole === 'admin' ? 'مدير عام المنظومة' :
          currentRole === 'finance' ? 'مسؤول الإدارة المالية' :
          currentRole === 'supervisor' ? 'مشرف المحطة' : 'فني التموين'
        }
      />

      {/* Secret Admin Authentication Modal (0000) */}
      <AdminModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        correctPin={config.adminPin}
        onSuccess={handleAdminSuccess}
      />

      {/* Financial Management Authentication Modal (1234) */}
      <FinanceModal
        isOpen={isFinanceModalOpen}
        onClose={() => setIsFinanceModalOpen(false)}
        correctPin={config.financePin || '1234'}
        adminPin={config.adminPin || '0000'}
        onSuccess={handleFinanceSuccess}
      />

      {/* Egyptian Voice & Interactive Assistant "مُعِين" */}
      <MoenAssistant
        config={config}
        currentRole={currentRole}
        onNavigateTo={handleRoleChange}
      />

      {/* Footer with Intellectual Property & Rights */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-center text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <div className="flex flex-wrap items-center justify-center gap-2 text-slate-700 font-bold">
            <span>منظومة كارجاس المتكاملة لإدارة المحطات وبرنامج الولاء الذكي</span>
            <span>•</span>
            <span className="text-emerald-700">شركة عزوتي للبرمجيات وتكنولوجيا المعلومات</span>
            <span>•</span>
            <span className="text-slate-900">المطور: محمد عبد الرحمن يوسف</span>
          </div>
          <p className="text-[11px] text-slate-400">
            كافة حقوق الملكية الفكرية وتصميم المنظومة وبرمجتها ومساعدها الذكي "مُعين" تعود بالكامل وبشكل حصري لـ "شركة عزوتي للبرمجيات وتكنولوجيا المعلومات" والمالك والمطور "محمد عبد الرحمن يوسف".
          </p>
          <div className="pt-1 text-[10px] text-slate-400 flex items-center justify-center gap-2">
            <span>سعر المتر: {config.gasPricePerMeter} ج</span>
            <span>•</span>
            <span>نطاق الأمان: 10 أمتار GPS</span>
            <span>•</span>
            <span>النسخة: v3.0 Enterprise Complete</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
